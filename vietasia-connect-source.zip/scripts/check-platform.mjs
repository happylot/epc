import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readdirSync } from 'node:fs';
import path from 'node:path';
const base=process.argv[2]||'http://127.0.0.1:5173';
if(!['localhost','127.0.0.1'].includes(new URL(base).hostname))throw new Error('Checks are restricted to a local preview.');
const login=await fetch(base+'/signin-with-chatgpt?return_to=/',{redirect:'manual'});
const cookie=login.headers.get('set-cookie')?.split(';')[0];assert.ok(cookie,'Local preview sign-in cookie required');
async function call(body,expected=200,authenticated=true,extra={}){const res=await fetch(base+'/api/platform',{method:body?'POST':'GET',headers:{...(authenticated?{cookie}:{}),...(body?{'content-type':'application/json',origin:base}:{}),...extra},...(body?{body:JSON.stringify(body)}:{})});const text=await res.text();let data;try{data=JSON.parse(text);}catch{data={error:text};}assert.equal(res.status,expected,JSON.stringify(data));return data;}
const directory=path.resolve('.wrangler/state/v3/d1/miniflare-D1DatabaseObject');
const dbFile=readdirSync(directory).find(f=>f.endsWith('.sqlite')&&f!=='metadata.sqlite');assert.ok(dbFile);
const db=new DatabaseSync(path.join(directory,dbFile));db.exec('PRAGMA busy_timeout=5000');
const run=crypto.randomUUID(),foreignCompany='qa-company-'+run,foreignOpportunity='qa-opportunity-'+run,foreignConnection='qa-connection-'+run;
const now=new Date().toISOString();let ownOpportunity;
const group='digital';const initial=await call();const initialMember=initial.memberships.some(m=>m.groupId===group);
try{
  db.prepare('INSERT INTO companies(id,owner_id,name,country,city,industry,role,description,products,markets,contact_email,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(foreignCompany,'qa-foreign-'+run,'QA foreign buyer','SG','Singapore','food','buyer','Local integration test foreign account','Coffee','["VN"]','qa@example.com',now);
  db.prepare('INSERT INTO opportunities(id,owner_id,company_name,title,kind,country,industry,quantity,deadline,description,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(foreignOpportunity,'qa-foreign-'+run,'QA buyer','QA foreign opportunity','buy','SG','food','10 tonnes','2027-01-30','Local foreign opportunity for ownership verification.',now);
  db.prepare('INSERT INTO connections(id,sender_id,sender_name,recipient_id,target_id,target_name,subject,message,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(foreignConnection,'qa-sender-'+run,'QA sender','qa-recipient-'+run,foreignCompany,'QA buyer','Private foreign conversation','This conversation must not appear in the local account.',now);
  await call({action:'save',targetId:foreignCompany,kind:'company'},401,false);
  await call({action:'save',targetId:foreignCompany,kind:'company'},401,false,{'oai-authenticated-user-id':'spoof','oai-authenticated-user-email':'spoof@example.com'});
  await call({action:'save',targetId:foreignCompany,kind:'company'},403,true,{origin:'https://other.example'});
  assert.ok(!(await call()).connections.some(c=>c.id===foreignConnection),'Foreign inbox must stay private');
  await call({action:'stage',id:foreignConnection,status:'won'},403);
  await call({action:'opportunity',data:{id:foreignOpportunity,title:'Unauthorized edit',companyName:'QA',kind:'buy',country:'SG',industry:'food',quantity:'10 tonnes',deadline:'2027-01-30',description:'This attempt to edit another account must be rejected.',requirements:''}},403);
  await call({action:'connect',data:{targetId:foreignCompany,kind:'company',subject:'QA enquiry',message:'Local integration enquiry about coffee sourcing and capacity.',date:''}},201);
  const connection=(await call()).connections.find(c=>c.targetId===foreignCompany);assert.ok(connection);assert.equal(connection.recipientId,'qa-foreign-'+run);assert.equal(connection.isDemo,0);
  await call({action:'stage',id:connection.id,status:'quoted'});assert.equal((await call()).connections.find(c=>c.id===connection.id).status,'quoted');
  const opportunity={title:'QA local opportunity '+run,companyName:'QA supplier',kind:'sell',country:'VN',industry:'food',quantity:'5 tonnes',deadline:new Date(Date.now()+30*864e5).toISOString().slice(0,10),description:'A detailed local integration test opportunity for account-owned records.',requirements:''};
  ownOpportunity=(await call({action:'opportunity',data:opportunity},201)).id;
  await call({action:'opportunity',data:{...opportunity,deadline:'2026-99-99'}},400);
  await call({action:'save',targetId:foreignCompany,kind:'company'});assert.ok((await call()).saved.some(s=>s.targetId===foreignCompany));
  await call({action:'save',targetId:foreignCompany,kind:'company'});assert.ok(!(await call()).saved.some(s=>s.targetId===foreignCompany));
  if(initialMember)await call({action:'group',groupId:group});
  await call({action:'post',groupId:group,content:'QA local test '+run},403);
  await call({action:'group',groupId:group});await call({action:'post',groupId:group,content:'QA local test '+run},201);
  assert.ok((await call()).posts.some(p=>p.content==='QA local test '+run));
  const sample=await call({action:'connect',data:{targetId:'demo-c1',kind:'company',subject:'QA sample '+run,message:'Local sample integration request that should remain a draft.',date:''}},201);assert.ok(sample.ok);
  const draft=(await call()).connections.find(c=>c.subject==='QA sample '+run);assert.equal(draft.status,'draft');await call({action:'stage',id:draft.id,status:'won'},400);
  console.log('PASS: sign-in, spoofed identity rejected, cross-origin protection, private inbox, foreign ownership checks, real recipient routing, stage update, opportunity creation, date validation, bookmark toggle, community permissions, and sample drafts.');
}finally{
  db.prepare('DELETE FROM connections WHERE id=? OR target_id=? OR subject=?').run(foreignConnection,foreignCompany,'QA sample '+run);
  db.prepare('DELETE FROM saved WHERE target_id=?').run(foreignCompany);
  db.prepare('DELETE FROM posts WHERE content=?').run('QA local test '+run);
  if(!initialMember)db.prepare('DELETE FROM memberships WHERE user_id=? AND group_id=?').run('local_seedy',group);
  db.prepare('DELETE FROM opportunities WHERE id=? OR id=?').run(foreignOpportunity,ownOpportunity||'');
  db.prepare('DELETE FROM companies WHERE id=?').run(foreignCompany);db.close();
}
