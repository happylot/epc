# Image credits

- `public/images/asia-port.jpg`: CHUTTERSNAP, “Assorted shipping trailers in port”, Bukit Merah, Singapore. Unsplash photograph: https://unsplash.com/photos/assorted-shipping-trailers-in-port-aT5-sSYP6e4 . Used under the Unsplash License: https://unsplash.com/license . Downloaded from the photograph's images.unsplash.com link, resized to 1400px.
- Logo, decorative routes and community illustrations: original SVG and CSS created for VietAsia Connect.

All company profiles, opportunities and events shipped in `app/lib/data.ts` are fictional demonstration content, labelled in the product. No ConnectAmericas database, brand, testimonials or institutional partnerships are reused.
