import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const companies = sqliteTable('companies', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), name: text('name').notNull(),
  country: text('country').notNull(), city: text('city').notNull(), industry: text('industry').notNull(),
  role: text('role').notNull(), description: text('description').notNull(), website: text('website').notNull().default(''),
  products: text('products').notNull().default(''), markets: text('markets').notNull().default('[]'),
  certifications: text('certifications').notNull().default(''), contactEmail: text('contact_email').notNull(),
  createdAt: text('created_at').notNull(),
});
export const opportunities = sqliteTable('opportunities', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull(), companyName: text('company_name').notNull(),
  title: text('title').notNull(), kind: text('kind').notNull(), country: text('country').notNull(),
  industry: text('industry').notNull(), quantity: text('quantity').notNull(), deadline: text('deadline').notNull(),
  description: text('description').notNull(), requirements: text('requirements').notNull().default(''), createdAt: text('created_at').notNull(),
});
export const saved = sqliteTable('saved', {
  userId: text('user_id').notNull(), targetId: text('target_id').notNull(), kind: text('kind').notNull(), createdAt: text('created_at').notNull(),
}, t => [primaryKey({columns:[t.userId,t.targetId,t.kind]})]);
export const connections = sqliteTable('connections', {
  id: text('id').primaryKey(), senderId: text('sender_id').notNull(), senderName: text('sender_name').notNull(),
  recipientId: text('recipient_id'), targetId: text('target_id').notNull(), targetName: text('target_name').notNull(),
  subject: text('subject').notNull(), message: text('message').notNull(), date: text('preferred_date').notNull().default(''),
  status: text('status').notNull().default('pending'), isDemo: integer('is_demo').notNull().default(0), createdAt: text('created_at').notNull(),
});
export const registrations = sqliteTable('registrations', {
  userId: text('user_id').notNull(), eventId: text('event_id').notNull(), createdAt: text('created_at').notNull(),
}, t => [primaryKey({columns:[t.userId,t.eventId]})]);
export const memberships = sqliteTable('memberships', {
  userId: text('user_id').notNull(), groupId: text('group_id').notNull(), createdAt: text('created_at').notNull(),
}, t => [primaryKey({columns:[t.userId,t.groupId]})]);
export const posts = sqliteTable('posts', {
  id: text('id').primaryKey(), groupId: text('group_id').notNull(), userId: text('user_id').notNull(),
  author: text('author').notNull(), content: text('content').notNull(), createdAt: text('created_at').notNull(),
});
