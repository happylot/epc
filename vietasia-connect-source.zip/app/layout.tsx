import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VietAsia Connect — Kết nối giao thương Việt Nam & châu Á",
  description: "Khám phá đối tác, cơ hội mua bán và cộng đồng doanh nghiệp Việt Nam — châu Á. Kết nối B2B, sự kiện và kiến thức xuất khẩu trên một nền tảng.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="antialiased">{children}</body>
    </html>
  );
}
