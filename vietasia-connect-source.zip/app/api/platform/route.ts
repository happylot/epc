import { and, desc, eq, or } from 'drizzle-orm';
import { z } from 'zod';
import { getDb } from '../../../db';
import * as tables from '../../../db/schema';
import { getChatGPTUser } from '../../chatgpt-auth';
import { countries, industries, demoCompanies, demoOpportunities, events, groups, resources } from '../../lib/data';

export const dynamic = 'force-dynamic';
const countryIds = countries.map(c=>c.id);
const industryIds = industries.map(i=>i.id);
const str=(min=1,max=200)=>z.string().trim().min(min).max(max);
const country=str(2,2).refine(s=>countryIds.includes(s));
const industry=str().refine(s=>industryIds.includes(s));
const calendarDate=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{const n=Date.parse(s+'T12:00:00Z');return Number.isFinite(n)&&new Date(n).toISOString().slice(0,10)===s;});
const companyInput=z.object({name:str(2,120),country,city:str(2,80),industry,role:z.enum(['supplier','buyer','service']),description:str(20,3000),website:z.union([z.literal(''),z.string().url().max(300)]).refine(s=>!s||/^https?:\/\//i.test(s)),products:str(2,1000),markets:z.array(country).max(12),certifications:z.string().trim().max(500),contactEmail:z.string().trim().email().max(200)});
const opportunityInput=z.object({id:z.string().max(100).optional(),title:str(5,160),companyName:str(2,120),kind:z.enum(['buy','sell','service']),country,industry,quantity:str(2,200),deadline:calendarDate,description:str(20,4000),requirements:z.string().trim().max(1500)});
function json(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'private, no-store'}});}
function problem(error:unknown){console.error('Platform request failed',error instanceof Error?error.message:'unknown');return json({error:'Không thể xử lý yêu cầu lúc này. Vui lòng thử lại. / Unable to process this request. Please try again.'},500);}

export async function GET(){
  try{
    const db=getDb(); const user=await getChatGPTUser();
    const [companyRows,opportunityRows]=await Promise.all([
      db.select().from(tables.companies).orderBy(desc(tables.companies.createdAt)).limit(300),
      db.select().from(tables.opportunities).orderBy(desc(tables.opportunities.createdAt)).limit(300),
    ]);
    let personal={saved:[] as unknown[],connections:[] as unknown[],registrations:[] as unknown[],memberships:[] as unknown[]};
    if(user){
      const [s,c,r,m]=await Promise.all([
        db.select().from(tables.saved).where(eq(tables.saved.userId,user.userId)),
        db.select().from(tables.connections).where(or(eq(tables.connections.senderId,user.userId),eq(tables.connections.recipientId,user.userId))).orderBy(desc(tables.connections.createdAt)).limit(200),
        db.select().from(tables.registrations).where(eq(tables.registrations.userId,user.userId)),
        db.select().from(tables.memberships).where(eq(tables.memberships.userId,user.userId)),
      ]);personal={saved:s,connections:c,registrations:r,memberships:m};
    }
    const postRows=await db.select({id:tables.posts.id,groupId:tables.posts.groupId,author:tables.posts.author,content:tables.posts.content,createdAt:tables.posts.createdAt}).from(tables.posts).orderBy(desc(tables.posts.createdAt)).limit(100);
    return json({companies:companyRows.map(c=>({...c,markets:JSON.parse(c.markets),demo:false})),opportunities:opportunityRows.map(o=>({...o,demo:false})),posts:postRows,...personal});
  }catch(error){return problem(error);}
}

export async function POST(request:Request){
  try{
    const origin=request.headers.get('origin');
    if(origin && new URL(origin).host!==new URL(request.url).host) return json({error:'Origin not allowed'},403);
    const user=await getChatGPTUser();if(!user)return json({error:'Vui lòng đăng nhập để tiếp tục. / Please sign in to continue.'},401);
    const length=Number(request.headers.get('content-length')||0);if(length>24000)return json({error:'Nội dung quá dài / Request too large'},413);
    const raw=await request.text();if(raw.length>24000)return json({error:'Nội dung quá dài / Request too large'},413);
    let body:any;try{body=JSON.parse(raw);}catch{return json({error:'Dữ liệu không hợp lệ / Invalid data'},400);}
    const db=getDb();const now=new Date().toISOString();const uid=user.userId;
    switch(body.action){
      case 'company':{
        const input=companyInput.safeParse(body.data);if(!input.success)return json({error:'Vui lòng kiểm tra thông tin doanh nghiệp, email và website. / Please check your business details, email and website.'},400);
        const [existing]=await db.select().from(tables.companies).where(eq(tables.companies.ownerId,uid)).limit(1);
        const data={...input.data,markets:JSON.stringify(input.data.markets)};
        if(existing){await db.update(tables.companies).set(data).where(and(eq(tables.companies.id,existing.id),eq(tables.companies.ownerId,uid)));return json({ok:true,id:existing.id});}
        const id=crypto.randomUUID();await db.insert(tables.companies).values({...data,id,ownerId:uid,createdAt:now});return json({ok:true,id},201);
      }
      case 'opportunity':{
        const input=opportunityInput.safeParse(body.data);if(!input.success)return json({error:'Vui lòng điền đủ tiêu đề, nội dung, số lượng và hạn nhận hồ sơ. / Complete the opportunity details and deadline.'},400);
        const {id,...data}=input.data;
        if(new Date(data.deadline+'T23:59:59Z').getTime()<Date.now())return json({error:'Hạn nhận hồ sơ phải từ hôm nay trở đi. / The deadline must be today or later.'},400);
        if(id){const [owned]=await db.select().from(tables.opportunities).where(and(eq(tables.opportunities.id,id),eq(tables.opportunities.ownerId,uid))).limit(1);if(!owned)return json({error:'Không có quyền chỉnh sửa / Not authorized'},403);await db.update(tables.opportunities).set(data).where(and(eq(tables.opportunities.id,id),eq(tables.opportunities.ownerId,uid)));return json({ok:true,id});}
        const newId=crypto.randomUUID();await db.insert(tables.opportunities).values({...data,id:newId,ownerId:uid,createdAt:now});return json({ok:true,id:newId},201);
      }
      case 'save':{
        const input=z.object({targetId:str(1,100),kind:z.enum(['company','opportunity','resource'])}).safeParse(body);if(!input.success)return json({error:'Invalid target'},400);
        const {targetId,kind}=input.data;
        const known=kind==='resource'?resources.some(r=>r.id===targetId):kind==='company'?demoCompanies.some(c=>c.id===targetId)||(await db.select().from(tables.companies).where(eq(tables.companies.id,targetId)).limit(1)).length>0:demoOpportunities.some(o=>o.id===targetId)||(await db.select().from(tables.opportunities).where(eq(tables.opportunities.id,targetId)).limit(1)).length>0;
        if(!known)return json({error:'Không tìm thấy nội dung / Content not found'},404);
        const where=and(eq(tables.saved.userId,uid),eq(tables.saved.targetId,targetId),eq(tables.saved.kind,kind));
        const existing=await db.select().from(tables.saved).where(where).limit(1);
        if(existing.length)await db.delete(tables.saved).where(where);else await db.insert(tables.saved).values({userId:uid,targetId,kind,createdAt:now}).onConflictDoNothing();return json({ok:true,saved:!existing.length});
      }
      case 'connect':{
        const input=z.object({targetId:str(1,100),kind:z.enum(['company','opportunity']),subject:str(3,180),message:str(20,3000),date:z.union([z.literal(''),calendarDate])}).safeParse(body.data);if(!input.success)return json({error:'Vui lòng nhập tiêu đề, lời nhắn từ 20 ký tự và ngày hợp lệ. / Enter a subject, a message of at least 20 characters and a valid date.'},400);
        const d=input.data;
        const demo=d.kind==='company'?demoCompanies.find(c=>c.id===d.targetId):demoOpportunities.find(o=>o.id===d.targetId);
        const real=demo?undefined:d.kind==='company'?(await db.select().from(tables.companies).where(eq(tables.companies.id,d.targetId)).limit(1))[0]:(await db.select().from(tables.opportunities).where(eq(tables.opportunities.id,d.targetId)).limit(1))[0];
        if(!demo&&!real)return json({error:'Không tìm thấy đối tác / Partner not found'},404);
        if(real?.ownerId===uid)return json({error:'Đây là nội dung của bạn / This is your own listing'},400);
        const targetName=demo?('name' in demo?demo.name:demo.companyName):real?('name' in real?real.name:real.companyName):'';
        await db.insert(tables.connections).values({id:crypto.randomUUID(),senderId:uid,senderName:user.displayName,recipientId:real?.ownerId??null,targetId:d.targetId,targetName,subject:d.subject,message:d.message,date:d.date,status:demo?'draft':'pending',isDemo:demo?1:0,createdAt:now});return json({ok:true,demo:!!demo},201);
      }
      case 'stage':{
        const input=z.object({id:str(1,100),status:z.enum(['pending','contacted','quoted','negotiating','won','lost','archived'])}).safeParse(body);if(!input.success)return json({error:'Invalid stage'},400);
        const [connection]=await db.select().from(tables.connections).where(and(eq(tables.connections.id,input.data.id),or(eq(tables.connections.senderId,uid),eq(tables.connections.recipientId,uid)))).limit(1);
        if(!connection)return json({error:'Không có quyền truy cập / Not authorized'},403);
        if(connection.isDemo&&input.data.status!=='archived')return json({error:'Yêu cầu minh họa chỉ lưu dưới dạng bản nháp. / Sample requests remain drafts.'},400);
        await db.update(tables.connections).set({status:input.data.status}).where(eq(tables.connections.id,connection.id));return json({ok:true});
      }
      case 'event':{
        const id=body.eventId;if(!events.some(e=>e.id===id))return json({error:'Event not found'},404);
        const where=and(eq(tables.registrations.userId,uid),eq(tables.registrations.eventId,id));const existing=await db.select().from(tables.registrations).where(where).limit(1);
        if(existing.length)await db.delete(tables.registrations).where(where);else await db.insert(tables.registrations).values({userId:uid,eventId:id,createdAt:now}).onConflictDoNothing();return json({ok:true,registered:!existing.length});
      }
      case 'group':{
        const id=body.groupId;if(!groups.some(g=>g.id===id))return json({error:'Group not found'},404);
        const where=and(eq(tables.memberships.userId,uid),eq(tables.memberships.groupId,id));const existing=await db.select().from(tables.memberships).where(where).limit(1);
        if(existing.length)await db.delete(tables.memberships).where(where);else await db.insert(tables.memberships).values({userId:uid,groupId:id,createdAt:now}).onConflictDoNothing();return json({ok:true,joined:!existing.length});
      }
      case 'post':{
        const input=z.object({groupId:str(1,60),content:str(10,2000)}).safeParse(body);if(!input.success||!groups.some(g=>g.id===input.data.groupId))return json({error:'Bài viết cần từ 10 đến 2.000 ký tự. / Posts must be 10–2,000 characters.'},400);
        const member=await db.select().from(tables.memberships).where(and(eq(tables.memberships.userId,uid),eq(tables.memberships.groupId,input.data.groupId))).limit(1);if(!member.length)return json({error:'Hãy tham gia cộng đồng trước khi đăng bài. / Join the community before posting.'},403);
        await db.insert(tables.posts).values({id:crypto.randomUUID(),groupId:input.data.groupId,userId:uid,author:user.displayName,content:input.data.content,createdAt:now});return json({ok:true},201);
      }
      default:return json({error:'Yêu cầu không hợp lệ / Invalid action'},400);
    }
  }catch(error){return problem(error);}
}
