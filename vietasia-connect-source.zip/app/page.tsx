import TradeApp from './trade-app';
import { getChatGPTUser } from './chatgpt-auth';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const user = await getChatGPTUser();
  return <TradeApp user={user ? {id:user.userId,name:user.displayName,email:user.email} : null} />;
}
