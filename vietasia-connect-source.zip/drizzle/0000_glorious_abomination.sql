CREATE TABLE `companies` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`name` text NOT NULL,
	`country` text NOT NULL,
	`city` text NOT NULL,
	`industry` text NOT NULL,
	`role` text NOT NULL,
	`description` text NOT NULL,
	`website` text DEFAULT '' NOT NULL,
	`products` text DEFAULT '' NOT NULL,
	`markets` text DEFAULT '[]' NOT NULL,
	`certifications` text DEFAULT '' NOT NULL,
	`contact_email` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `connections` (
	`id` text PRIMARY KEY NOT NULL,
	`sender_id` text NOT NULL,
	`sender_name` text NOT NULL,
	`recipient_id` text,
	`target_id` text NOT NULL,
	`target_name` text NOT NULL,
	`subject` text NOT NULL,
	`message` text NOT NULL,
	`preferred_date` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`is_demo` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `memberships` (
	`user_id` text NOT NULL,
	`group_id` text NOT NULL,
	`created_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `group_id`)
);
--> statement-breakpoint
CREATE TABLE `opportunities` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`company_name` text NOT NULL,
	`title` text NOT NULL,
	`kind` text NOT NULL,
	`country` text NOT NULL,
	`industry` text NOT NULL,
	`quantity` text NOT NULL,
	`deadline` text NOT NULL,
	`description` text NOT NULL,
	`requirements` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `posts` (
	`id` text PRIMARY KEY NOT NULL,
	`group_id` text NOT NULL,
	`user_id` text NOT NULL,
	`author` text NOT NULL,
	`content` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `registrations` (
	`user_id` text NOT NULL,
	`event_id` text NOT NULL,
	`created_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `event_id`)
);
--> statement-breakpoint
CREATE TABLE `saved` (
	`user_id` text NOT NULL,
	`target_id` text NOT NULL,
	`kind` text NOT NULL,
	`created_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `target_id`, `kind`)
);
