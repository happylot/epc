# VietAsia Connect

Vietnamese–English B2B business community for Vietnam and Asia. New member information is self-declared; demonstration companies, opportunities and events are explicitly labelled.

## Available workflows

- Company directory: search without Vietnamese accents, country/industry/business-role filters, profile details, favourites, public business contacts.
- Company profile: one editable profile per account through the interface, target markets, capabilities, products and self-declared certifications.
- Opportunity board: create and edit sourcing requests, product offers and service partnerships; date and input validation.
- Connections: account-owned introductions and recipient inboxes, progress stages; requests to sample businesses remain drafts.
- Communities: join/leave industry communities and post discussions after joining.
- Events: save/cancel sample event registrations, download UTC-based iCalendar entries with GMT+7 display.
- Knowledge library: practical full-text guides, saved articles and links to official trade resources.
- Workspace: profile management, bookmarks, connection requests, own opportunities, event registrations, community membership.
- Vietnamese and English interface, responsive layouts, keyboard-accessible modal focus management.

## Authentication and persistence

Sites owns Sign in with ChatGPT and site access policy. The stable site-specific user ID owns records. D1 persists business records; browser storage holds only language preference. API writes require authenticated identity and reject cross-origin requests. Connection records are restricted to sender and recipient; listing updates require ownership.

`.openai/hosting.json` declares the `DB` binding. Schema changes belong in `db/schema.ts` and generated, immutable Drizzle migrations. Sample data is shipped in `app/lib/data.ts`; no development database or test records are deployed.

## Local development

Use Node >=22.13.0, install with the Sites helper, then `npm run dev`. Portable preview offers a local-only test sign-in; production uses the hosting authentication gate.

Validation: `node node_modules/typescript/bin/tsc --noEmit --incremental false`; `node scripts/check-platform.mjs` against a running local preview. The integration script only accepts loopback targets, creates isolated local fixtures and removes them afterward.

## Operating the community

This release is a working initial platform with sample listings, not an existing network of verified buyers. Events are examples with no live meeting links. Matching uses industry, target markets and business roles; it does not call a paid AI API. Introductions stay within the platform and no email or external messaging provider is configured.

Before opening to external members, the operator should choose the public-facing brand, membership and moderation process, business-verification process, and a real event programme. Source changes and audience changes are separate operations; deployment preserves the site's existing audience.
